#pragma once
#include <iostream>
using namespace std;
#include <cstring>
#include <fstream>
#include <iomanip>
#include "item.h"
#include "itemList.h"

int main(int argc, char ** argv);


